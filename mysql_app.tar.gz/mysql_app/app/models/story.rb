class Story < ApplicationRecord
	validates :name, :summary , presence: { message: " is empty" }
	validates :name , uniqueness: { message: "is already taken" }

end
