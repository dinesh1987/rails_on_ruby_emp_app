class StoriesController < ApplicationController
	before_action :set_story, only:
	[:show]
	def index
		@stories = Story.all
		
	end
	 
	def show
	end

	def new
		@story = Story.new
		
	end	
	
	def create
  	@story = Story.new(story_params)

    	respond_to do |format|
      		if @story.save
        	format.html { redirect_to @story, notice: 'Story was successfully created.' }
        format.json { render :show, status: :created, location: @story }
      else
        format.html { render :new }
        format.json { render json: @story.errors, status: :unprocessable_entity }
		end
		end
		end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_story
      @story = Story.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def story_params
      params.require(:story).permit(:name, :summary)
    end
	
end
