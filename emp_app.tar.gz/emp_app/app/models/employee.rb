class Employee < ActiveRecord::Base
acts_as_paranoid
paginates_per 5

	 def self.search(param)
		param.strip!
		param.downcase!
		to_send_back = (name_matches(param) + designation_matches(param) + project_matches(param)).uniq
		return nil unless to_send_back
		to_send_back
  	 end
  
	def self.name_matches(param)
	matches('name',param)
	end

	def self.designation_matches(param)
	matches('designation',param)
	end

	def self.project_matches(param)
	matches('project',param)
	end

	def self.matches(field_name, param)
	Employee.where("#{field_name} like ?","%#{param}%")
	end
	
end
