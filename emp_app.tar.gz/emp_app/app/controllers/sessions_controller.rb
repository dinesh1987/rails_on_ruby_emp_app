class SessionsController < ApplicationController

  def new
  end

  def create
    user = User.find_by(name: params[:name])
    if user and user.authenticate(params[:password])
      session[:user_id] = user.id
      session[:user_name] = user.name
      redirect_to root_path, alert: "User logged in successfully"
    else
      #redirect_to login_path, alert: "Invalid User name or password"
 	flash.now[:danger] = "Invalid User name or password"
	render 'new'
    end
  end

  def destroy
  	session[:user_id] = nil
  	redirect_to login_path, alert: "User logged out :D"
  end
end
