class EmployeeController < ApplicationController
	before_action :is_logged_in
	before_action :set_employee, only: [:show, :edit, :update, :destroy]	
	

	def index	

		@employees = Employee.all
		#Employee.only_deleted 
		#Employee.with_deleted
	end


	def show
			@employee_grid = initialize_grid(Employee)
	end
	
	def new
		#byebug
		@employee= Employee.new
			@employee_grid = initialize_grid(Employee)
	end

	def create
		@employee = Employee.new(employee_params)
		
			if @employee.save
				
				
				redirect_to new_employee_path , notice: 'Employee was successfully added.'
				
			else		
				
				render :new
				
			end
		end
	

	def edit
	end

	def update
		respond_to do |format|
			if @employee.update(employee_params)
				format.html {redirect_to @employee , notice: 'Employee details was updated.'}
        			format.json { render :show, status: :ok, location: @employee }	
			else
				format.html {render :edit}		
		        	format.json { render json: @employee.errors, status: :unprocessable_entity }
			end
		end	

	end

	def destroy
		@employee.destroy
		redirect_to root_path, notice: 'Employee has been removed successfully' 
	end 
	
	def search
       if params[:employee_search].blank?
          flash.now[:danger] = "Input is Blank. Kindly Enter Something"
       else
         @employees = Employee.search(params[:employee_search]) 
	 flash.now[:danger] = "No Employee available for the search" if @employees.blank?
  
		render 'result' 
        end
          
      
         
      end 
    

	private
		def set_employee
		  @employee = Employee.find(params[:id])
		end
		
		def employee_params
		  params.require(:employee).permit(:name, :designation, :project)
		end	

end
