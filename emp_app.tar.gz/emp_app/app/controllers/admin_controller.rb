class AdminController < ApplicationController
  def index
	if (session[:user_name] != "admin") then
		redirect_to '/403'
	end
  
  end
end
