class GridController < ApplicationController

	def index
	@employee_grid = initialize_grid(Employee)
	end

end

