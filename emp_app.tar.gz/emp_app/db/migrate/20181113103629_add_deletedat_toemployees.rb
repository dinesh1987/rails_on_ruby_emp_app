class AddDeletedatToemployees < ActiveRecord::Migration
    def change
	add_column :employees, :deleted_at, :time
  end
end
