class AddDeletedToEmployess < ActiveRecord::Migration
  def change
    add_column :employees, :deleted, :string
  end
end
